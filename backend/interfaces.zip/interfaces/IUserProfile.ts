export interface IUserProfile {
  getProfile(userId: string): Promise<ProfileData>;
  updateProfile(data: any): void;   
}

export interface ProfileData {
  userId: string;
  name?: string;
  email?: string;
}