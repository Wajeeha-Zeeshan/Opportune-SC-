export interface ICourseManagement {
  submitApplication(studentId: string, jobId: string): void; 
  checkEnrollment(studentId: string): boolean;
  checkEnrollment(): boolean;
}