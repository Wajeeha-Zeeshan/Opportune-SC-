export interface IChatService {
  userStatus: string;

  applyToInternship(studentId: string, jobId: string): Promise<string>;
 
}