export interface IApplicationProcessing {
  studentId: string;
  submitApplication(studentId: string, jobId: string): Promise<void>;
  checkEnrollment(studentId: string): boolean;
  setForInternship(status: string): void;
    
}