export interface IAccessControl {
  roleMask: number;

  getPermissions(session: any): Permissions;   
  isAuthorized(session: any, resource: string): boolean;
}

export type Permissions = string[] | number; 