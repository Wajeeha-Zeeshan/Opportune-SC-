export interface IAuthentication {
  userStatus: string;

  login(credentials: any): Promise<SessionToken>;  
  logout(token: string): void;
  validateToken(token: string): boolean;
}
export interface SessionToken {
  token: string;
  expiresIn: number;

}